﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace VoidUpdate.GoToUnity
{
    static class PkgCmdIDList
    {
        public const uint GoToUnity =        0x100;


    };
}